const toggle = document.querySelector(".menu-toggle");
const nav = document.querySelector(".nav");

toggle?.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  toggle.setAttribute("aria-expanded", open ? "true" : "false");
});

document.querySelectorAll(".nav a").forEach(link => {
  link.addEventListener("click", () => nav.classList.remove("open"));
});

const sections = document.querySelectorAll("main section[id]");
const navLinks = document.querySelectorAll(".nav a");

const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      navLinks.forEach(link => link.classList.remove("active"));
      const current = document.querySelector(`.nav a[href="#${entry.target.id}"]`);
      current?.classList.add("active");
    }
  });
}, { rootMargin: "-35% 0px -55% 0px" });

sections.forEach(section => observer.observe(section));

document.getElementById("year").textContent = new Date().getFullYear();

document.getElementById("contactForm")?.addEventListener("submit", e => {
  e.preventDefault();
  const data = new FormData(e.currentTarget);
  const name = data.get("name");
  const phone = data.get("phone");
  const email = data.get("email");
  const message = data.get("message");

  const text =
    `Bonjour AGRO PLUS BUSINESS,%0A%0A` +
    `Nom : ${encodeURIComponent(name)}%0A` +
    `Téléphone : ${encodeURIComponent(phone)}%0A` +
    `E-mail : ${encodeURIComponent(email || "Non renseigné")}%0A%0A` +
    `Message : ${encodeURIComponent(message)}`;

  window.open(`https://wa.me/22376933993?text=${text}`, "_blank");
  document.getElementById("formMessage").textContent =
    "Votre demande est prête à être envoyée sur WhatsApp.";
});
