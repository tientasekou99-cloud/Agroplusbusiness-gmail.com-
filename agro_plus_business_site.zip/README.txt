# AGRO PLUS BUSINESS — Site web

## Utilisation
1. Décompressez le fichier ZIP.
2. Gardez `index.html`, `style.css`, `script.js` et `logo.jpg` dans le même dossier.
3. Double-cliquez sur `index.html` pour ouvrir le site dans Chrome ou Edge.

## Mise en ligne
Le site est statique : il peut être publié sur un hébergement classique.
Avant publication, remplacez si nécessaire :
- le numéro WhatsApp/téléphone ;
- l'adresse e-mail ;
- les textes ;
- les photos de démonstration par les vraies photos de l'entreprise.

Le formulaire de contact ouvre actuellement WhatsApp avec le message prérempli.
